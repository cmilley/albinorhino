import xbmcaddon

'''#####-----Build File-----#####'''
buildfile = 'https://www.dropbox.com/scl/fi/olf1b8f5il0uk5dugb7bj/Builds.xml?rlkey=58mhudlo25a4qcai9k4wnkcz7&dl=1'

'''#####-----Notifications File-----#####'''
notify_url  = 'https://www.dropbox.com/scl/fi/05y5mht6uasrooiotn7ye/Message.txt?rlkey=tbs8lfx89332vzfrg0vxirvzz&dl=1'

'''#####-----Excludes-----#####'''
excludes  = ['plugin.video.whatever.']
